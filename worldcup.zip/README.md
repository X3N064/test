### 시연 URL
<http://study.koreaup.co.kr/lezhin>

### Pure javascript lezhin 코딩 과제
 + 이상형 월드컵을 개발해 보자.
